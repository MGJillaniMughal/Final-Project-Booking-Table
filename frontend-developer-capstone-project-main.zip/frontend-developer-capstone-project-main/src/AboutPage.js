function AboutPage() {
    return (
        <>About Me</>
    );
}

export default AboutPage;